Web crawler which crawls and build a site map of all the urls which has same domain as the domain given by the initial Site URL.

Requirements :
Start URL with proper domain name and protocol.

Results :
Print a list of line where each line start contains the main link followed by a list of links which is connected to the main link.

Limitations / Improvements :
1. The programme is single threaded. Each url is parsed one by one and a lot of time is wasted on network I/O. We can use multiple crawlers
concurrently to improve the speed of the programme.
2. Site map is printed in console in a very normal way. We can store the map in some DB or File to use in future.
3. There is no repeat crawling. Every website is crawled only once. We might need to crawl a website again and again (more popular page more frequently)
as the website will keep changing.

Site Map Printing :
Every line has an integer count in the beginning which denotes the depth of that url in the site map.
