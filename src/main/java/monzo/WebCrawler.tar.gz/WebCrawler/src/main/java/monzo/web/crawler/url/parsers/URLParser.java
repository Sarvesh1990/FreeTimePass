package monzo.web.crawler.url.parsers;


import java.io.IOException;
import java.net.URL;
import java.util.Set;

public interface URLParser {
    //Needed to prevent 403 response via JSOUP
    static final String USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/33.0.1750.152 Safari/537.36";
    static final String LINK_CSS_QUERY_ATTR = "a[href]";
    static final String LINK_HTML_ATTR_KEY = "href";

    public Set<URL> getLinkedUrls(URL parentURL);
}
