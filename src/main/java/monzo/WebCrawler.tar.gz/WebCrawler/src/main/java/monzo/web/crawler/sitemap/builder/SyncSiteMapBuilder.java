package monzo.web.crawler.sitemap.builder;


import monzo.web.crawler.url.parsers.SameHostURLParser;
import monzo.web.crawler.url.parsers.URLParser;

import java.net.URL;
import java.util.*;

/*
Synchronous site map builder. Will initialise single instance of parser and will build the map.
 */
public class SyncSiteMapBuilder extends SiteMapBuilder {
    public SyncSiteMapBuilder() {
        super(new HashMap<>());
    }

    @Override
    public void buildSiteMap(URL startUrl) {
        URLParser parser = new SameHostURLParser(startUrl);

        Queue<URL> upcomingURLsToBeCrawled = new ArrayDeque<>();
        Set<URL> visitedURLs = new HashSet<>();

        upcomingURLsToBeCrawled.add(startUrl);
        visitedURLs.add(startUrl);

        //Looping till we have parsed all the links once
        while(!upcomingURLsToBeCrawled.isEmpty()) {
            URL currentURL = upcomingURLsToBeCrawled.remove();
            Set<URL> linkedURLs = parser.getLinkedUrls(currentURL);

            //Storing all the urls which has no outgoing links too. If we don't want those urls we can just change this to !linkedURLs.isEmpty()
            if(linkedURLs != null) {
                linkedURLMap.put(currentURL, linkedURLs);
                for (URL url : linkedURLs) {
                    if (!visitedURLs.contains(url)) {
                        upcomingURLsToBeCrawled.add(url);
                        visitedURLs.add(url);
                    }
                }
            }
        }
    }
}
