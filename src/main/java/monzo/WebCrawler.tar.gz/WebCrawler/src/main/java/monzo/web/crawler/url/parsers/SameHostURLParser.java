package monzo.web.crawler.url.parsers;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

/*
Checks for links present in the given url and return all those links which has the same host as the start url.
Needs a start url while creating object to match the host.
 */
public class SameHostURLParser implements URLParser {
    //Needed because we need to check startHost for each parsedURL
    private URL startURL;

    public SameHostURLParser(URL startUrl) {
        this.startURL = startUrl;
    }

    @Override
    public Set<URL> getLinkedUrls(URL parentURL) {
        Set<URL> relevantURLs = new HashSet();

        //Keeping in try/catch block to prevent non-existing urls (Like 404)
        try {
            Document doc = Jsoup.connect(parentURL.toString()).userAgent(USER_AGENT).ignoreContentType(true).get();
            Elements outgoingLinks = doc.select(LINK_CSS_QUERY_ATTR);

            for(Element outgoingLink : outgoingLinks){
                URL outgoingLinkHrefURL = buildOutgoingURL(outgoingLink.attr(LINK_HTML_ATTR_KEY));
                if(outgoingLinkHrefURL != null) {
                    //Check if outgoing url is of same domain as start url. Do we need to check protocol too?
                    if (outgoingLinkHrefURL.getHost().equals(this.startURL.getHost())) {
                        relevantURLs.add(outgoingLinkHrefURL);
                    }
                }
            }
        } catch (Exception e) {
        }

        return relevantURLs;
    }

    private URL buildOutgoingURL(String outgoingLinkHref) {
        //Add host and protocol to urls with relative path
        if (outgoingLinkHref.startsWith("/")) {
            outgoingLinkHref = this.startURL.getProtocol() + "://" + this.startURL.getHost() + outgoingLinkHref;
        }

        //Delete trailing slashes to prevent duplicates
        if (outgoingLinkHref.endsWith("/")) {
            outgoingLinkHref = outgoingLinkHref.substring(0, outgoingLinkHref.length() - 1);
        }

        try {
            URL url = new URL(outgoingLinkHref);
            return url;
        } catch (MalformedURLException var8) {
            return null;
        }
    }
}
