package monzo.web.crawler.sitemap.printer;


import java.net.URL;
import java.util.*;

/*
Simple site map printer. Prints the map on console. Can write other implementation or print the site map in a beautiful way.
 */
public class SimpleSiteMapPrinter implements SiteMapPrinter {
    @Override
    public void printSiteMap(Map<URL, Set<URL>> linkedURLsMap, URL startURL) {
        Queue<URL> urlsToPrint = new ArrayDeque<>();
        urlsToPrint.add(startURL);

        Set<URL> printedURLs = new HashSet<>();
        printedURLs.add(startURL);

        //Count denotes the depth of the url in sitemap
        int count = 1;

        while(!urlsToPrint.isEmpty()) {
            Queue<URL> tempQueue = new ArrayDeque<>();
            while (!urlsToPrint.isEmpty()) {
                //To print all urls at same depth with same count number
                tempQueue.add(urlsToPrint.remove());
            }

            while (!tempQueue.isEmpty()) {
                URL currentURL = tempQueue.remove();
                Set<URL> linkedURLs = linkedURLsMap.get(currentURL);

                //Printing all the urls which has no outgoing links too. If we don't want those urls we can just change this to !linkedURLs.isEmpty()
                if (linkedURLs != null) {
                    System.out.println(count + ". " + currentURL + " -> " + linkedURLs);
                    for (URL url : linkedURLs) {
                        if (!printedURLs.contains(url)) {
                            urlsToPrint.add(url);
                            printedURLs.add(url);
                        }
                    }
                }
            }
            count++;
        }
    }
}
